<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <style>
    * {
        font-family: Arial, Helvetica, sans-serif;
    }
    .infos {
      margin-top: -400px;
      margin-left: 450px;
      line-height: 0px;
    }

    ul {
      list-style: none;
    }

    li {
      margin-top: -10px;
    }

    table{
      text-align: center;
      border-collapse: collapse;
    }

    td{
      font-size: small;
      padding: 6px;
    }
    .total{
      margin-top: 10px;
      margin-left: 77.4%;
    }
  </style>
</head>

<body>
  <div class="top">
    <h1 class="logo">VLDO</h1>
    <div class="infos">
      <ul>

        <li>

          <h4>Livreur: <strong> <?php echo e(ucfirst($factorisation->delivery->firstname)); ?> <?php echo e(ucfirst($factorisation->delivery->lastname)); ?> </strong></h4>
        </li>
        <li>

          <h4>Client: Vldo</h4>
        </li>
        <li>

          <h4>RIB:</h4>
        </li>
        <li>

          <h4>Nb. commandes: <?php echo e($factorisation->commands_number); ?></h4>
        </li>
        <li>

          <h4>Date: <?php echo e($factorisation->created_at); ?></h4>
        </li>
      </ul>
    </div>
  </div>
  <h3 style="text-align: center; font-size:30px; font-weight:bolder;"> <?php echo e($factorisation->factorisation_id); ?> </h3>
  <table border="1px">
    <tr>
      <th>#</th>
      <th>Code d'envoi</th>
      <th>Date livraison</th>
      <th>Téléphone</th>
      <th>Ville</th>
      <th>Produit</th>
      
      <th>CRBT</th>
      <th>Frais</th>
    </tr>
    <?php $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td> <?php echo e($sale->id); ?> </td>
      <td> <?php echo e($sale->cmd); ?> </td>
      <td> <?php echo e($sale->delivery_date); ?> </td>
      <td> <?php echo e($sale->phone); ?> </td>
      <td> <?php echo e($sale->city); ?> </td>
      <td> x<?php echo e(count($sale->items->pluck('product')->pluck('name'))); ?> </td>
      
      <td> <?php echo e($sale->price); ?> </td>
      <td> <?php $__currentLoopData = $factorisation->delivery->deliveryPlaces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deliveryPlace): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($deliveryPlace->city->name === $sale->city): ?>
        <?php echo e($deliveryPlace->fee); ?>

        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </table>
  <table class="total" border="2px">
    <tr>
      <th>Total Brut :</th>
      <td><?php echo e($factorisation->price); ?></td>
    </tr>
    <tr>
      <th>Frais :</th>
      <td> <?php
        $totalFees = 0;
        ?>

        <?php $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $__currentLoopData = $factorisation->delivery->deliveryPlaces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deliveryPlace): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($deliveryPlace->city->name === $sale->city): ?>
        <?php
        $totalFees += $deliveryPlace->fee;
        ?>
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php echo e($totalFees); ?> DH
      </td>
      <tr>
        <th>Total Net :</th>
        <td><?php echo e($factorisation->price - $totalFees); ?> DH</td>
      </tr>
    </tr>
  </table>
</body>

</html>
<?php /**PATH D:\FIVERR\livraison\backend\projectdelivery\resources\views/factorisationpdf.blade.php ENDPATH**/ ?>